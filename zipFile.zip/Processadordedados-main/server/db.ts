import { drizzle } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import dns from 'dns';
import * as schema from '@shared/schema';

dns.setDefaultResultOrder('ipv4first');

const originalLookup = dns.lookup;
dns.lookup = ((hostname: string, options: any, callback: any) => {
  if (typeof options === 'function') {
    callback = options;
    options = { family: 4 };
  } else if (typeof options === 'number') {
    options = { family: 4 };
  } else {
    options = { ...options, family: 4 };
  }
  return originalLookup(hostname, options, callback);
}) as typeof dns.lookup;

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error('DATABASE_URL environment variable is required');
}

const isProduction = process.env.NODE_ENV === 'production';

const poolConfig: pg.PoolConfig = {
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
  ...(isProduction && {
    ssl: {
      rejectUnauthorized: false,
    },
  }),
};

const pool = new Pool(poolConfig);

pool.on('error', (err) => {
  console.error('Database pool error:', err.message);
});

pool.on('connect', () => {
  console.log('Database connection established (IPv4 forced)');
});

export const db = drizzle(pool, { schema });
export { pool };
