import {
  type UploadedFile,
  type InsertConsolidatedRecord,
  uploadedFiles,
  sheetMetadata,
  columnMappings,
  consolidatedRecords,
} from "@shared/schema";
import { db } from "./db";
import { eq, inArray } from "drizzle-orm";
import XLSX from "xlsx";
import { parse } from "csv-parse";

/* ===========================
   HELPERS
=========================== */

const normalize = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9 ]/g, "")
    .trim();

const cleanNumber = (value: any) => {
  if (!value) return null;
  const v = value.toString().replace(/\D/g, "");
  return v || null;
};

const filledCount = (obj: any) =>
  Object.values(obj).filter((v) => v !== null && v !== "").length;

/* ===========================
   FIELD MAP (EXPORT AMPLO)
=========================== */

const FIELD_MAP = {
  name: [
    "nome", "nomecompleto", "nome completo", "name", "cliente", "nome cliente",
    "nome do cliente", "comprador", "proprietario", "segurado", "paciente",
    "funcionario", "colaborador", "consumidor", "pessoa", "razao social",
    "titular", "socio", "representante", "responsavel", "diretor", "vendedor",
  ],
  cpfCnpj: [
    "cpf", "cnpj", "cpf cnpj", "cpfcnpj", "documento", "cgc", "doc",
    "cpf_cliente", "cpfcliente", "cnpjempresa", "cpf do cliente",
  ],
  phone: [
    "telefone", "tel", "fone", "phone", "ramal", "fax",
    "celular", "cel", "movel", "mobile", "telefonecelular", "telcel",
    "fonecelular", "telefonemovel", "fonemovel", "celulartel",
    "whatsapp", "wpp", "zap", "contato",
  ],
  address: [
    "endereco", "logradouro", "address", "rua", "r.", "avenida", "av", "av.",
    "alameda", "travessa", "estrada", "rodovia", "end", "logr",
  ],
  number: ["numero", "nro", "num", "number", "no"],
  complement: [
    "complemento", "compl", "comp", "apto", "apartamento", "casa", "bloco", "sala", "apt",
  ],
  neighborhood: ["bairro", "district", "neighborhood"],
  city: ["cidade", "municipio", "localidade", "city"],
  state: ["estado", "uf", "sigla", "est", "provincia", "state"],
  cep: ["cep", "zip", "zipcode", "postalcode", "codigo postal"],
  ticketAverage: [
    "ticket medio", "ticketmedio", "ticket", "faturamento",
    "valor", "valor compra", "valor total", "total", "preco", "price",
  ],
  purchaseDate: [
    "data compra", "datacompra", "data", "dt", "data venda", "datavenda",
    "ultima compra", "data_venda", "date", "dataemissao", "data emissao",
    "dt. ult. compra", "dt ult compra", "dtultcompra", "ultima compra",
  ],
  produto: [
    "produto", "product", "mercadoria", "item", "descricao produto",
    "descricaoproduto", "nome produto", "nomeproduto", "servico",
  ],
  quantidade: [
    "quantidade", "qtd", "qt", "qtde", "qty", "quant", "qnt",
    "qtdade", "qtidade",
  ],
};

/* ===========================
   STORAGE
=========================== */

export class DatabaseStorage {
  /* ========= FILES ========= */

  async getAllFiles() {
    return await db
      .select()
      .from(uploadedFiles)
      .orderBy(uploadedFiles.createdAt); // corrigido
  }

  async deleteFile(id: string) {
    await db.delete(uploadedFiles).where(eq(uploadedFiles.id, id));
  }

  async deleteAllFiles() {
    await db.delete(uploadedFiles);
  }

  /* ========= CONSOLIDATED ========= */

  async getAllConsolidated() {
    return await db
      .select()
      .from(consolidatedRecords)
      .orderBy(consolidatedRecords.createdAt);
  }

  async deleteConsolidatedByIds(ids: string[]): Promise<number> {
    if (!ids || ids.length === 0) return 0;

    const result = await db
      .delete(consolidatedRecords)
      .where(inArray(consolidatedRecords.id, ids))
      .returning({ id: consolidatedRecords.id });

    return result.length;
  }

  async previewDeduplicate(type: "phone" | "name"): Promise<{
    duplicateGroups: number;
    toRemove: number;
    toKeep: number;
  }> {
    const all = await db.select().from(consolidatedRecords);
    const { toDelete, groups } = this._buildDeduplicateIds(all, type);
    return {
      duplicateGroups: groups,
      toRemove: toDelete.length,
      toKeep: all.length - toDelete.length,
    };
  }

  async deduplicate(type: "phone" | "name"): Promise<{
    removed: number;
    kept: number;
  }> {
    const all = await db.select().from(consolidatedRecords);
    const { toDelete } = this._buildDeduplicateIds(all, type);

    if (toDelete.length > 0) {
      await db
        .delete(consolidatedRecords)
        .where(inArray(consolidatedRecords.id, toDelete));
    }

    return { removed: toDelete.length, kept: all.length - toDelete.length };
  }

  private _buildDeduplicateIds(
    all: any[],
    type: "phone" | "name"
  ): { toDelete: string[]; groups: number } {
    const buckets = new Map<string, any[]>();

    for (const record of all) {
      let key: string;

      if (type === "phone") {
        const digits = (record.phone || "").replace(/\D/g, "");
        if (!digits) continue;
        key = digits;
      } else {
        const norm = normalize(record.name || "");
        if (!norm) continue;
        key = norm;
      }

      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key)!.push(record);
    }

    const toDelete: string[] = [];
    let groups = 0;

    for (const group of buckets.values()) {
      if (group.length <= 1) continue;
      groups++;
      group.sort((a: any, b: any) => filledCount(b) - filledCount(a));
      for (let i = 1; i < group.length; i++) {
        toDelete.push(group[i].id);
      }
    }

    return { toDelete, groups };
  }

  /* ========= UPLOAD & PROCESS ========= */

  async saveFile(originalName: string, buffer: Buffer): Promise<UploadedFile> {
    const [uploadedFile] = await db
      .insert(uploadedFiles)
      .values({
        originalName,
        fileType: originalName.split(".").pop()?.toLowerCase() || "unknown",
        fileSize: buffer.length,
        status: "processing",
      })
      .returning();

    try {
      const ext = originalName.split(".").pop()?.toLowerCase();
      let sheets: { name: string; data: any[] }[] = [];

      if (ext === "csv") {
        const csvString = buffer.toString("latin1");
        // Detecta delimitador automaticamente (;  ,  |  \t)
        const firstLine = csvString.split(/\r?\n/)[0] || "";
        const counts = {
          ";": (firstLine.match(/;/g) || []).length,
          ",": (firstLine.match(/,/g) || []).length,
          "|": (firstLine.match(/\|/g) || []).length,
          "\t": (firstLine.match(/\t/g) || []).length,
        };
        const delimiter = (Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0]) as string;

        const records: any[] = await new Promise((resolve, reject) => {
          parse(
            csvString,
            { columns: true, delimiter, trim: true, skip_empty_lines: true, relax_quotes: true },
            (err, output) => (err ? reject(err) : resolve(output))
          );
        });
        sheets = [{ name: originalName, data: records }];
      } else {
        const workbook = XLSX.read(buffer, { type: "buffer", cellDates: false, raw: false });
        sheets = workbook.SheetNames.map((name) => ({
          name,
          data: XLSX.utils.sheet_to_json(workbook.Sheets[name], { defval: null, raw: false }),
        }));
      }

      const allRecords: InsertConsolidatedRecord[] = [];

      for (const sheet of sheets) {
        if (!sheet.data.length) continue;

        const headers = Object.keys(sheet.data[0]).map(normalize);

        const [meta] = await db
          .insert(sheetMetadata)
          .values({
            fileId: uploadedFile.id,
            sheetName: sheet.name,
            sheetIndex: sheets.indexOf(sheet),
            rowCount: sheet.data.length,
            columnCount: headers.length,
            columnNames: headers,
          })
          .returning();

        await db.insert(columnMappings).values(
          headers.map((h, i) => ({
            sheetId: meta.id,
            originalColumnName: h,
            columnIndex: i,
          }))
        );

        for (const row of sheet.data) {
          const normalizedRow = Object.fromEntries(
            Object.entries(row).map(([k, v]) => [normalize(k), typeof v === "string" ? v.trim() : v])
          );

          const getField = (keys: string[]) => {
            for (const key of keys) {
              const v = normalizedRow[normalize(key)];
              if (v !== undefined && v !== null && v !== "") return v;
            }
            return null;
          };

          allRecords.push({
            name: getField(FIELD_MAP.name),
            cpf: cleanNumber(getField(FIELD_MAP.cpfCnpj)),
            phone: cleanNumber(getField(FIELD_MAP.phone)),
            address: getField(FIELD_MAP.address),
            number: getField(FIELD_MAP.number),
            complement: getField(FIELD_MAP.complement),
            neighborhood: getField(FIELD_MAP.neighborhood),
            city: getField(FIELD_MAP.city),
            state: getField(FIELD_MAP.state),
            cep: cleanNumber(getField(FIELD_MAP.cep)),
            ticketAverage: Number(getField(FIELD_MAP.ticketAverage)) || null,
            purchaseDate: getField(FIELD_MAP.purchaseDate),
            produto: getField(FIELD_MAP.produto),
            quantidade: getField(FIELD_MAP.quantidade),
            status: "valid",
            confidence: 80,
            sourceFiles: [uploadedFile.id],
          });
        }
      }

      const map = new Map<string, InsertConsolidatedRecord>();
      for (const rec of allRecords) {
        const key = `${rec.name || ""}-${rec.phone || rec.cpf || ""}`;
        const existing = map.get(key);
        if (!existing || filledCount(rec) > filledCount(existing)) {
          map.set(key, rec);
        }
      }

      const finalRecords = Array.from(map.values());

      const BATCH = 1000;
      for (let i = 0; i < finalRecords.length; i += BATCH) {
        await db.insert(consolidatedRecords).values(finalRecords.slice(i, i + BATCH));
      }

      await db
        .update(uploadedFiles)
        .set({
          status: "completed",
          totalSheets: sheets.length,
          totalRows: finalRecords.length,
          totalColumns: Object.keys(finalRecords[0] || {}).length,
        })
        .where(eq(uploadedFiles.id, uploadedFile.id));

      return { ...uploadedFile, status: "completed" };
    } catch (err) {
      await db.update(uploadedFiles).set({ status: "error" }).where(eq(uploadedFiles.id, uploadedFile.id));
      throw err;
    }
  }
}

export const storage = new DatabaseStorage();
