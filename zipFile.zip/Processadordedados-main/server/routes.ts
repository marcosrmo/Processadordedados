import { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { getAllFieldPatterns, getFieldDisplayName } from "./fileProcessor";
import { previewDedup, runDedup, type DedupeType } from "./dedup";
import multer from "multer";
import express from "express";
import { db } from "./db";
import { columnMappings, sheetMetadata } from "@shared/schema";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 500 * 1024 * 1024,
    files: 500,
  },
});

export async function registerRoutes(app: Express): Promise<Server> {

  /* =========================
     MIDDLEWARE ESSENCIAL
  ========================= */

  app.use(express.json());

  /* =========================
     UPLOAD DE ARQUIVOS
  ========================= */

  app.post("/api/files/upload", upload.array("files"), async (req, res) => {
    req.setTimeout(30 * 60 * 1000);
    res.setTimeout(30 * 60 * 1000);
    try {
      const files = req.files as Express.Multer.File[];

      if (!files || files.length === 0) {
        return res.status(400).json({ error: "Nenhum arquivo" });
      }

      const results = [];

      for (const file of files) {
        console.log(`[UPLOAD] processando: ${file.originalname} (${(file.buffer.length / 1024 / 1024).toFixed(1)} MB)`);
        const savedFile = await storage.saveFile(
          file.originalname,
          file.buffer
        );
        results.push(savedFile);
      }

      res.status(201).json(results);
    } catch (error) {
      console.error("Erro no upload:", error);
      res.status(500).json({ error: "Falha ao processar upload" });
    }
  });

  /* =========================
     FILES
  ========================= */

  app.get("/api/files", async (_req, res) => {
    const files = await storage.getAllFiles();
    res.json(files);
  });

  app.delete("/api/files/:id", async (req, res) => {
    await storage.deleteFile(req.params.id);
    res.json({ success: true });
  });

  app.delete("/api/files", async (_req, res) => {
    await storage.deleteAllFiles();
    res.json([]);
  });

  /* =========================
     FIELDS / ANALYSIS
  ========================= */

  app.get("/api/fields", (_req, res) => {
    res.json(getAllFieldPatterns());
  });

  app.get("/api/analysis/mappings", async (_req, res) => {
    try {
      const mappings = await db
        .select({
          id: columnMappings.id,
          sheetId: columnMappings.sheetId,
          originalColumnName: columnMappings.originalColumnName,
          columnIndex: columnMappings.columnIndex,
          mappedFieldName: columnMappings.mappedFieldName,
          detectionMethod: columnMappings.detectionMethod,
          confidence: columnMappings.confidence,
          sampleValues: columnMappings.sampleValues,
        })
        .from(columnMappings)
        .orderBy(columnMappings.sheetId, columnMappings.columnIndex);

      const enriched = mappings.map((m) => ({
        ...m,
        displayName: m.mappedFieldName ? getFieldDisplayName(m.mappedFieldName) : null,
      }));

      res.json({ mappings: enriched });
    } catch (error) {
      console.error("Erro ao buscar mapeamentos:", error);
      res.status(500).json({ error: "Falha ao carregar mapeamentos" });
    }
  });

  /* =========================
     CONSOLIDATED
  ========================= */

  app.get("/api/consolidated", async (_req, res) => {
    const records = await storage.getAllConsolidated();
    res.json(records);
  });

  app.post("/api/consolidated/delete-exported", async (req, res) => {
    const { ids } = req.body as { ids: string[] };

    if (!ids || ids.length === 0) {
      return res.status(400).json({ error: "Nenhum ID recebido" });
    }

    const deleted = await storage.deleteConsolidatedByIds(ids);

    console.log(`[CONSOLIDATED] ${deleted} registros excluídos após exportação`);

    res.json({ success: true, deleted });
  });

  /* =========================
     DEDUPLICAÇÃO  (paths simples para evitar conflito com Vite)
  ========================= */

  const VALID_DEDUP_TYPES = ["phone", "phone9", "name", "cpf", "cnpj", "combined"] as const;

  app.get("/api/dedup-preview", async (req, res) => {
    const type = req.query.type as string;
    if (!VALID_DEDUP_TYPES.includes(type as any)) {
      return res.status(400).json({ error: "type inválido" });
    }
    try {
      const result = await previewDedup(type as DedupeType);
      console.log(`[DEDUP PREVIEW] type=${type}`, result);
      res.json(result);
    } catch (err) {
      console.error("[DEDUP PREVIEW]", err);
      res.status(500).json({ error: "Erro ao analisar duplicatas" });
    }
  });

  app.post("/api/dedup-run", async (req, res) => {
    const { type } = req.body as { type: string };
    if (!VALID_DEDUP_TYPES.includes(type as any)) {
      return res.status(400).json({ error: "type inválido" });
    }
    try {
      const result = await runDedup(type as DedupeType);
      console.log(`[DEDUP RUN] type=${type} removed=${result.removed} kept=${result.kept}`);
      res.json({ success: true, ...result });
    } catch (err) {
      console.error("[DEDUP RUN]", err);
      res.status(500).json({ error: "Erro ao remover duplicatas" });
    }
  });

  return createServer(app);
}
