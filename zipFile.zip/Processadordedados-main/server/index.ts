import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import cors from "cors";
import path from "path";

const app = express();

app.use(cors());
app.use(express.json({ limit: "500mb" }));
app.use(express.urlencoded({ extended: true, limit: "500mb" }));

(async () => {
  const server = await registerRoutes(app);

  const PORT = Number(process.env.PORT) || 5000;

  if (process.env.NODE_ENV === "production") {
    const { serveStatic } = await import("./static");
    serveStatic(app);
  } else {
    const { setupVite } = await import("./vite");
    await setupVite(server, app);
  }

  server.setTimeout(30 * 60 * 1000);
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`[BACKEND] Servidor rodando em 0.0.0.0:${PORT}`);
  });
})();
