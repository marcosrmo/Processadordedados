import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";

// Componentes UI
import { Toaster } from "./components/ui/toaster";
import { TooltipProvider } from "./components/ui/tooltip";
import { SidebarProvider, SidebarInset } from "./components/ui/sidebar";

// Sidebar e páginas
import { AppSidebar } from "./components/layout/AppSidebar";
import NotFound from "./pages/not-found";

// Páginas (ajuste os caminhos se necessário)
import Dashboard from "./pages/Dashboard";
import Import from "./pages/Import";
import Consolidation from "./pages/Consolidation";
import Export from "./pages/Export";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/import" component={Import} />
      <Route path="/consolidation" component={Consolidation} />
      <Route path="/export" component={Export} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider defaultOpen={true}>
          <div className="flex min-h-screen w-full bg-background">
            {/* Sidebar lateral */}
            <AppSidebar />

            {/* Conteúdo principal */}
            <SidebarInset className="flex-1 overflow-auto">
              <Router />
            </SidebarInset>
          </div>

          {/* Toast para notificações */}
          <Toaster />
        </SidebarProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
