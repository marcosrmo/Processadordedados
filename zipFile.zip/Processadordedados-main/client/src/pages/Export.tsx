import { useCallback, useEffect, useMemo, useState } from "react";
import { useDragScroll } from "@/hooks/useDragScroll";
import type { ConsolidatedRecord } from "@shared/schema";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Download,
  Trash2,
  RefreshCw,
  FileSpreadsheet,
  Filter,
  ScanSearch,
  Phone,
  User,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

/* ===========================
   COLUNAS DISPONÍVEIS
=========================== */

const ALL_COLUMNS: { key: string; label: string }[] = [
  { key: "phone",        label: "Telefone" },
  { key: "name",         label: "Nome" },
  { key: "cpf",          label: "CNPJ/CPF" },
  { key: "city",         label: "Cidade" },
  { key: "address",      label: "Logradouro" },
  { key: "number",       label: "Número" },
  { key: "complement",   label: "Complemento" },
  { key: "neighborhood", label: "Bairro" },
  { key: "state",        label: "UF" },
  { key: "cep",          label: "CEP" },
  { key: "purchaseDate", label: "Dt. Últ. Compra" },
  { key: "produto",      label: "Produto" },
  { key: "quantidade",   label: "Quantidade" },
  { key: "ticketAverage",label: "Ticket Médio" },
];

type DedupeType = "phone" | "phone9" | "name" | "cpf" | "cnpj" | "combined";

interface DedupePreview {
  duplicateGroups: number;
  toRemove: number;
  toKeep: number;
}

export default function Export() {
  const [records, setRecords] = useState<ConsolidatedRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleting, setDeleting] = useState(false);

  const [selectedCols, setSelectedCols] = useState<string[]>(
    ALL_COLUMNS.map((c) => c.key)
  );

  // Filtros de conteúdo
  const [filterCity, setFilterCity]         = useState("");
  const [filterState, setFilterState]       = useState("");
  const [filterProduct, setFilterProduct]   = useState("");
  const [onlyWithPhone, setOnlyWithPhone]   = useState(false);
  const [onlyWithCpf, setOnlyWithCpf]       = useState(false);
  const [onlyWithAddress, setOnlyWithAddress] = useState(false);
  const [removeUndesired, setRemoveUndesired] = useState(true);
  const [keepEngano, setKeepEngano]           = useState(false);

  // Deduplicação
  const [dedupeDialog, setDedupeDialog]     = useState<DedupeType | null>(null);
  const [dedupePreview, setDedupePreview]   = useState<DedupePreview | null>(null);
  const [dedupeLoading, setDedupeLoading]   = useState(false);
  const [dedupeRunning, setDedupeRunning]   = useState(false);

  const { toast } = useToast();
  const dragScroll = useDragScroll();

  const fetchRecords = useCallback(() => {
    setLoading(true);
    fetch("/api/consolidated")
      .then((r) => r.json())
      .then((data) => { setRecords(data || []); setLoading(false); })
      .catch(() => {
        toast({ variant: "destructive", title: "Erro", description: "Falha ao carregar dados" });
        setLoading(false);
      });
  }, [toast]);

  useEffect(() => { fetchRecords(); }, [fetchRecords]);

  /* ===========================
     FILTROS
  =========================== */

  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      if (onlyWithPhone && !r.phone) return false;
      if (onlyWithCpf && !r.cpf) return false;
      if (onlyWithAddress && !r.address) return false;
      if (filterCity && !r.city?.toLowerCase().includes(filterCity.toLowerCase())) return false;
      if (filterState && r.state?.toLowerCase() !== filterState.toLowerCase()) return false;
      if (filterProduct) {
        const prod = ((r as any).produto || "").toLowerCase();
        if (!prod.includes(filterProduct.toLowerCase())) return false;
      }
      if (!keepEngano && r.phone?.toLowerCase().includes("engano")) return false;
      if (removeUndesired) {
        const row = Object.values(r).join(" ").toLowerCase();
        const bad = [/\bsem\s+gado\b/, /\bs\/\s*gado\b/, /\bfalecido\b/, /\bxinga\b/, /\bgrita\b/];
        if (bad.some((rx) => rx.test(row))) return false;
      }
      return true;
    });
  }, [records, onlyWithPhone, onlyWithCpf, onlyWithAddress,
      filterCity, filterState, filterProduct, keepEngano, removeUndesired]);

  const removed = records.length - filteredRecords.length;
  const previewRows = filteredRecords.slice(0, 100);

  const toggleCol = (key: string) => {
    setSelectedCols((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
  };

  const activeCols = ALL_COLUMNS.filter((c) => selectedCols.includes(c.key));

  /* ===========================
     DEDUPLICAÇÃO
  =========================== */

  const openDedupeDialog = async (type: DedupeType) => {
    setDedupeDialog(type);
    setDedupePreview(null);
    setDedupeLoading(true);
    try {
      const res = await fetch(`/api/dedup-preview?type=${type}`);
      if (!res.ok) throw new Error();
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setDedupePreview(data);
    } catch (err) {
      toast({ variant: "destructive", title: "Erro", description: "Não foi possível analisar duplicatas." });
      setDedupeDialog(null);
    } finally {
      setDedupeLoading(false);
    }
  };

  const runDedupe = async () => {
    if (!dedupeDialog) return;
    setDedupeRunning(true);
    try {
      const res = await fetch("/api/dedup-run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: dedupeDialog }),
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      toast({
        title: "Duplicatas removidas",
        description: `${data.removed} registros removidos. ${data.kept} mantidos.`,
      });
      setDedupeDialog(null);
      setDedupePreview(null);
      fetchRecords();
    } catch {
      toast({ variant: "destructive", title: "Erro", description: "Falha ao remover duplicatas." });
    } finally {
      setDedupeRunning(false);
    }
  };

  /* ===========================
     EXPORTAR CSV
  =========================== */

  const exportCSV = () => {
    if (!filteredRecords.length) {
      toast({ variant: "destructive", title: "Nada para exportar" });
      return;
    }
    const headers = activeCols.map((c) => c.label).join(";");
    const rows = filteredRecords.map((r) =>
      activeCols.map(({ key }) => {
        const v = (r as any)[key];
        if (v == null) return "";
        return `"${v.toString().replace(/"/g, '""')}"`;
      }).join(";")
    );
    const csv = [headers, ...rows].join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `consolidado-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "CSV exportado", description: `${filteredRecords.length} registros` });
  };

  /* ===========================
     EXPORTAR EXCEL
  =========================== */

  const exportExcel = async () => {
    if (!filteredRecords.length) {
      toast({ variant: "destructive", title: "Nada para exportar" });
      return;
    }
    const XLSX = await import("xlsx");
    const rows = filteredRecords.map((r) => {
      const obj: Record<string, any> = {};
      activeCols.forEach(({ key, label }) => {
        obj[label] = (r as any)[key] ?? "";
      });
      return obj;
    });
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Consolidado");
    XLSX.writeFile(wb, `consolidado-${new Date().toISOString().split("T")[0]}.xlsx`);
    toast({ title: "Excel exportado", description: `${filteredRecords.length} registros` });
  };

  /* ===========================
     EXCLUIR TUDO
  =========================== */

  const deleteAll = async () => {
    if (!confirm(`Excluir todos os ${records.length} registros? Ação irreversível.`)) return;
    setDeleting(true);
    try {
      const ids = records.map((r) => r.id);
      const res = await fetch("/api/consolidated/delete-exported", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids }),
      });
      if (!res.ok) throw new Error();
      setRecords([]);
      toast({ title: "Todos os registros excluídos" });
    } catch {
      toast({ variant: "destructive", title: "Erro", description: "Falha ao excluir." });
    } finally {
      setDeleting(false);
    }
  };

  /* ===========================
     UI
  =========================== */

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center h-full">
        <RefreshCw className="animate-spin mr-2" size={20} />
        <span>Carregando dados...</span>
      </div>
    );
  }

  const DEDUPE_OPTIONS: { type: DedupeType; label: string; desc: string }[] = [
    { type: "phone",    label: "Telefone Exato",       desc: "Mesmo número de telefone (dígitos idênticos)" },
    { type: "phone9",   label: "Telefone + 9º Dígito", desc: "Normaliza celulares BR com/sem o 9 (ex: 11 9xxxx = 11 xxxx)" },
    { type: "name",     label: "Nome Exato",            desc: "Mesmo nome completo (ignora acentos e maiúsculas)" },
    { type: "cpf",      label: "CPF (11 dígitos)",      desc: "Mesmo CPF — apenas documentos com 11 dígitos" },
    { type: "cnpj",     label: "CNPJ (14 dígitos)",     desc: "Mesmo CNPJ — apenas documentos com 14 dígitos" },
    { type: "combined", label: "Telefone + Nome",       desc: "Mesmo telefone E mesmo nome juntos" },
  ];
  const dedupeOption = DEDUPE_OPTIONS.find(o => o.type === dedupeDialog);

  return (
    <div className="p-4 h-full flex flex-col gap-3 overflow-hidden">
      {/* CABEÇALHO */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold">Exportar Dados</h1>
          <p className="text-xs text-muted-foreground">Configure filtros e colunas antes de exportar</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="h-8 text-xs" onClick={fetchRecords}>
            <RefreshCw size={13} className="mr-1" /> Atualizar
          </Button>
          {records.length > 0 && (
            <Button size="sm" variant="destructive" className="h-8 text-xs" onClick={deleteAll} disabled={deleting}>
              <Trash2 size={13} className="mr-1" />
              {deleting ? "Excluindo..." : "Excluir Tudo"}
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 overflow-hidden flex-1 min-h-0">

        {/* PAINEL ESQUERDO */}
        <div className="flex flex-col gap-3 overflow-auto">

          {/* REMOVER DUPLICATAS */}
          {records.length > 0 && (
            <Card className="border-orange-200 bg-orange-50/40 dark:bg-orange-950/10 dark:border-orange-900">
              <CardHeader className="py-2 px-4 border-b border-orange-200 dark:border-orange-900">
                <CardTitle className="text-sm flex items-center gap-1.5 text-orange-700 dark:text-orange-400">
                  <ScanSearch size={14} /> Remover Duplicatas
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 space-y-1.5 text-xs">
                <p className="text-muted-foreground text-[11px] mb-2">
                  Mantém o registro com mais campos preenchidos e remove os demais.
                </p>
                {DEDUPE_OPTIONS.map((opt) => (
                  <Button
                    key={opt.type}
                    size="sm"
                    variant="outline"
                    className="w-full h-7 text-[11px] justify-start border-orange-300 hover:bg-orange-100 dark:hover:bg-orange-900/30"
                    onClick={() => openDedupeDialog(opt.type)}
                  >
                    <ScanSearch size={11} className="mr-1.5 shrink-0" />
                    <span className="font-medium">{opt.label}</span>
                    <span className="ml-1 text-muted-foreground hidden lg:inline truncate"> — {opt.desc}</span>
                  </Button>
                ))}
              </CardContent>
            </Card>
          )}

          {/* FILTROS DE CONTEÚDO */}
          <Card>
            <CardHeader className="py-2 px-4 border-b">
              <CardTitle className="text-sm flex items-center gap-1">
                <Filter size={14} /> Filtros de Conteúdo
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 space-y-2.5 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-[11px] mb-1 block">Cidade</Label>
                  <Input
                    placeholder="Ex: São Paulo"
                    className="h-7 text-xs"
                    value={filterCity}
                    onChange={(e) => setFilterCity(e.target.value)}
                  />
                </div>
                <div>
                  <Label className="text-[11px] mb-1 block">UF</Label>
                  <Input
                    placeholder="Ex: SP"
                    className="h-7 text-xs"
                    value={filterState}
                    onChange={(e) => setFilterState(e.target.value.toUpperCase())}
                    maxLength={2}
                  />
                </div>
              </div>
              <div>
                <Label className="text-[11px] mb-1 block">Produto</Label>
                <Input
                  placeholder="Filtrar por produto..."
                  className="h-7 text-xs"
                  value={filterProduct}
                  onChange={(e) => setFilterProduct(e.target.value)}
                />
              </div>
              <div className="space-y-1.5 pt-1 border-t">
                <Label className="text-[11px] text-muted-foreground uppercase tracking-wide">Obrigatório ter:</Label>
                <div className="flex items-center gap-2">
                  <Checkbox id="chk-phone" checked={onlyWithPhone} onCheckedChange={(v) => setOnlyWithPhone(v === true)} />
                  <Label htmlFor="chk-phone" className="text-xs cursor-pointer">Telefone preenchido</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox id="chk-cpf" checked={onlyWithCpf} onCheckedChange={(v) => setOnlyWithCpf(v === true)} />
                  <Label htmlFor="chk-cpf" className="text-xs cursor-pointer">CPF/CNPJ preenchido</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox id="chk-addr" checked={onlyWithAddress} onCheckedChange={(v) => setOnlyWithAddress(v === true)} />
                  <Label htmlFor="chk-addr" className="text-xs cursor-pointer">Endereço preenchido</Label>
                </div>
              </div>
              <div className="space-y-1.5 pt-1 border-t">
                <Label className="text-[11px] text-muted-foreground uppercase tracking-wide">Palavras indesejadas:</Label>
                <div className="flex items-center gap-2">
                  <Checkbox id="chk-undesired" checked={removeUndesired} onCheckedChange={(v) => setRemoveUndesired(v === true)} />
                  <Label htmlFor="chk-undesired" className="text-xs cursor-pointer">Remover: SEM GADO, FALECIDO, XINGA, GRITA</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox id="chk-engano" checked={keepEngano} onCheckedChange={(v) => setKeepEngano(v === true)} />
                  <Label htmlFor="chk-engano" className="text-xs cursor-pointer">Manter registros com ENGANO</Label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* SELEÇÃO DE COLUNAS */}
          <Card>
            <CardHeader className="py-2 px-4 border-b">
              <CardTitle className="text-sm">Colunas para Exportar</CardTitle>
            </CardHeader>
            <CardContent className="p-3 space-y-1.5 text-xs">
              <div className="flex gap-2 mb-2">
                <button className="text-[11px] text-primary underline" onClick={() => setSelectedCols(ALL_COLUMNS.map(c => c.key))}>Todas</button>
                <button className="text-[11px] text-muted-foreground underline" onClick={() => setSelectedCols([])}>Nenhuma</button>
              </div>
              {ALL_COLUMNS.map((col) => (
                <div key={col.key} className="flex items-center gap-2">
                  <Checkbox
                    id={`col-${col.key}`}
                    checked={selectedCols.includes(col.key)}
                    onCheckedChange={() => toggleCol(col.key)}
                  />
                  <Label htmlFor={`col-${col.key}`} className="text-xs cursor-pointer">{col.label}</Label>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* RESULTADO + BOTÕES */}
          <Card>
            <CardContent className="p-3 space-y-2 text-xs">
              <div className="flex justify-between">
                <span>Total carregado:</span>
                <strong>{records.length}</strong>
              </div>
              <div className="flex justify-between">
                <span>Após filtros:</span>
                <strong className="text-green-600">{filteredRecords.length}</strong>
              </div>
              <div className="flex justify-between">
                <span>Removidos:</span>
                <strong className="text-red-500">{removed}</strong>
              </div>
              <div className="flex justify-between">
                <span>Colunas selecionadas:</span>
                <strong>{activeCols.length}</strong>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <Button size="sm" className="h-8 text-xs gap-1" onClick={exportCSV} disabled={!filteredRecords.length}>
                  <Download size={13} /> CSV
                </Button>
                <Button size="sm" variant="outline" className="h-8 text-xs gap-1" onClick={exportExcel} disabled={!filteredRecords.length}>
                  <FileSpreadsheet size={13} /> Excel
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* PAINEL DIREITO — PRÉVIA (máx. 100 registros) */}
        <div className="lg:col-span-2 flex flex-col min-h-0">
          <Card className="flex-1 flex flex-col min-h-0 overflow-hidden">
            <CardHeader className="py-2 px-4 border-b flex-row items-center justify-between">
              <div>
                <CardTitle className="text-sm">Prévia dos Dados</CardTitle>
                <CardDescription className="text-[11px]">
                  {filteredRecords.length} registros · {activeCols.length} colunas
                  {filteredRecords.length > 100 && " · exibindo primeiros 100"}
                </CardDescription>
              </div>
              {filteredRecords.length > 0 && (
                <Badge variant="outline" className="text-green-600 border-green-300 text-[11px]">
                  Pronto para exportar
                </Badge>
              )}
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-auto">
              {filteredRecords.length === 0 ? (
                <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">
                  {records.length === 0
                    ? "Sem dados consolidados. Importe planilhas primeiro."
                    : "Nenhum registro passa pelos filtros atuais."}
                </div>
              ) : (
                <div
                  ref={dragScroll.ref}
                  style={{ fontSize: "11px", cursor: "grab", userSelect: "none", overflowX: "auto" }}
                  onMouseDown={dragScroll.onMouseDown}
                  onMouseLeave={dragScroll.onMouseLeave}
                  onMouseUp={dragScroll.onMouseUp}
                  onMouseMove={dragScroll.onMouseMove}
                >
                  <Table>
                    <TableHeader className="sticky top-0 bg-muted/80 z-10">
                      <TableRow>
                        {activeCols.map((c) => (
                          <TableHead key={c.key} className="py-1.5 px-2 whitespace-nowrap">{c.label}</TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {previewRows.map((r) => (
                        <TableRow key={r.id} className="hover:bg-muted/30">
                          {activeCols.map(({ key }) => (
                            <TableCell key={key} className="py-1 px-2 whitespace-nowrap max-w-[150px] truncate">
                              {(r as any)[key] || "—"}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* DIALOG DE CONFIRMAÇÃO DE DEDUPLICAÇÃO */}
      <Dialog
        open={!!dedupeDialog}
        onOpenChange={(open) => {
          if (!open && !dedupeRunning) { setDedupeDialog(null); setDedupePreview(null); }
        }}
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ScanSearch size={16} />
              Remover duplicatas — {dedupeOption?.label}
            </DialogTitle>
            <DialogDescription>
              {dedupeOption?.desc}. O registro com mais campos preenchidos é mantido;
              os demais são excluídos permanentemente.
            </DialogDescription>
          </DialogHeader>

          <div className="py-2">
            {dedupeLoading ? (
              <div className="flex items-center justify-center gap-2 py-6 text-muted-foreground text-sm">
                <RefreshCw size={16} className="animate-spin" />
                Analisando duplicatas...
              </div>
            ) : dedupePreview ? (
              dedupePreview.toRemove === 0 ? (
                <div className="rounded-lg bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 p-4 text-center">
                  <p className="text-green-700 dark:text-green-400 font-medium text-sm">
                    Nenhuma duplicata encontrada por <em>{dedupeOption?.label}</em>!
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Todos os {dedupePreview.toKeep} registros analisados são únicos.
                  </p>
                </div>
              ) : (
                <div className="rounded-lg bg-orange-50 dark:bg-orange-950/20 border border-orange-200 dark:border-orange-800 p-4 space-y-3">
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div>
                      <p className="text-2xl font-bold text-orange-600">{dedupePreview.duplicateGroups}</p>
                      <p className="text-xs text-muted-foreground">grupos duplicados</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-red-600">{dedupePreview.toRemove}</p>
                      <p className="text-xs text-muted-foreground">serão removidos</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-green-600">{dedupePreview.toKeep}</p>
                      <p className="text-xs text-muted-foreground">serão mantidos</p>
                    </div>
                  </div>
                  <p className="text-xs text-orange-700 dark:text-orange-400 text-center">
                    Esta ação não pode ser desfeita.
                  </p>
                </div>
              )
            ) : null}
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => { setDedupeDialog(null); setDedupePreview(null); }}
              disabled={dedupeRunning}
            >
              Cancelar
            </Button>
            {dedupePreview && dedupePreview.toRemove > 0 && (
              <Button
                variant="destructive"
                size="sm"
                onClick={runDedupe}
                disabled={dedupeRunning}
              >
                {dedupeRunning ? (
                  <><RefreshCw size={13} className="mr-1 animate-spin" /> Removendo...</>
                ) : (
                  <><Trash2 size={13} className="mr-1" /> Remover {dedupePreview.toRemove} duplicatas</>
                )}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
