import { useState, useEffect, useMemo, useCallback } from "react";
import { useDragScroll } from "@/hooks/useDragScroll";
import type { ConsolidatedRecord } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Trash2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Consolidation() {
  const [records, setRecords] = useState<ConsolidatedRecord[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deletingAll, setDeletingAll] = useState(false);
  const { toast } = useToast();
  const dragScroll = useDragScroll();

  const fetchRecords = useCallback(() => {
    setLoading(true);
    fetch("/api/consolidated")
      .then((res) => {
        if (!res.ok) throw new Error("Falha ao carregar dados");
        return res.json();
      })
      .then((data) => {
        setRecords(data || []);
        setLoading(false);
      })
      .catch(() => {
        toast({ variant: "destructive", title: "Erro", description: "Não foi possível carregar os dados." });
        setLoading(false);
      });
  }, [toast]);

  useEffect(() => { fetchRecords(); }, [fetchRecords]);

  const filteredRecords = useMemo(() => {
    if (!search) return records;
    const q = search.toLowerCase();
    return records.filter((r) =>
      JSON.stringify(Object.values(r)).toLowerCase().includes(q)
    );
  }, [records, search]);

  const deleteOne = async (id: string) => {
    setDeletingId(id);
    try {
      const res = await fetch("/api/consolidated/delete-exported", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: [id] }),
      });
      if (!res.ok) throw new Error();
      setRecords((prev) => prev.filter((r) => r.id !== id));
      toast({ title: "Registro excluído" });
    } catch {
      toast({ variant: "destructive", title: "Erro", description: "Falha ao excluir registro." });
    } finally {
      setDeletingId(null);
    }
  };

  const deleteAll = async () => {
    if (!confirm(`Excluir todos os ${records.length} registros consolidados? Esta ação não pode ser desfeita.`)) return;
    setDeletingAll(true);
    try {
      const ids = records.map((r) => r.id);
      const res = await fetch("/api/consolidated/delete-exported", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids }),
      });
      if (!res.ok) throw new Error();
      setRecords([]);
      toast({ title: "Todos os registros foram excluídos" });
    } catch {
      toast({ variant: "destructive", title: "Erro", description: "Falha ao excluir registros." });
    } finally {
      setDeletingAll(false);
    }
  };

  if (loading) {
    return (
      <div className="p-8 flex items-center justify-center h-full">
        <RefreshCw className="animate-spin mr-2" size={20} />
        <span>Carregando dados consolidados...</span>
      </div>
    );
  }

  return (
    <div className="p-4 h-full flex flex-col gap-3">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold">Consolidação de Dados</h1>
          <p className="text-xs text-muted-foreground">{records.length} registros consolidados</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              placeholder="Buscar..."
              className="pl-8 h-8 text-xs w-48"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Button size="sm" variant="outline" className="h-8 text-xs" onClick={fetchRecords}>
            <RefreshCw size={13} className="mr-1" /> Atualizar
          </Button>
          {records.length > 0 && (
            <Button
              size="sm"
              variant="destructive"
              className="h-8 text-xs"
              onClick={deleteAll}
              disabled={deletingAll}
            >
              <Trash2 size={13} className="mr-1" />
              {deletingAll ? "Excluindo..." : "Excluir Tudo"}
            </Button>
          )}
        </div>
      </div>

      <Card className="flex-1 min-h-0 overflow-hidden">
        <CardHeader className="py-2 px-4 border-b">
          <CardTitle className="text-sm">
            Mostrando {filteredRecords.length} de {records.length} registros
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 h-full overflow-auto">
          {filteredRecords.length === 0 ? (
            <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">
              {records.length === 0
                ? "Nenhum dado consolidado. Importe planilhas para começar."
                : "Nenhum resultado encontrado."}
            </div>
          ) : (
            <div
              ref={dragScroll.ref}
              className="overflow-auto"
              style={{ fontSize: "11px", cursor: "grab", userSelect: "none" }}
              onMouseDown={dragScroll.onMouseDown}
              onMouseLeave={dragScroll.onMouseLeave}
              onMouseUp={dragScroll.onMouseUp}
              onMouseMove={dragScroll.onMouseMove}
            >
              <Table>
                <TableHeader className="sticky top-0 bg-muted/80 z-10">
                  <TableRow>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Telefone</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Nome</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">CNPJ/CPF</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Cidade</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Logradouro</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Nº</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Complemento</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Bairro</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">UF</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">CEP</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Dt. Últ. Compra</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Produto</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Qtd</TableHead>
                    <TableHead className="py-1.5 px-2 whitespace-nowrap">Ação</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecords.map((record) => (
                    <TableRow key={record.id} className="hover:bg-muted/30">
                      <TableCell className="py-1 px-2 whitespace-nowrap">{record.phone || "—"}</TableCell>
                      <TableCell className="py-1 px-2 font-medium whitespace-nowrap max-w-[140px] truncate">{record.name || "—"}</TableCell>
                      <TableCell className="py-1 px-2 font-mono whitespace-nowrap">{record.cpf || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap">{record.city || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap max-w-[160px] truncate">{record.address || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap">{record.number || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap max-w-[100px] truncate">{record.complement || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap">{record.neighborhood || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap">
                        {record.state ? (
                          <Badge variant="outline" className="text-[10px] py-0 px-1">{record.state}</Badge>
                        ) : "—"}
                      </TableCell>
                      <TableCell className="py-1 px-2 font-mono whitespace-nowrap">{record.cep || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap">{record.purchaseDate || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap max-w-[120px] truncate">{(record as any).produto || "—"}</TableCell>
                      <TableCell className="py-1 px-2 whitespace-nowrap">{(record as any).quantidade || "—"}</TableCell>
                      <TableCell className="py-1 px-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-6 w-6 text-destructive hover:text-destructive"
                          disabled={deletingId === record.id}
                          onClick={() => deleteOne(record.id)}
                        >
                          <Trash2 size={12} />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
