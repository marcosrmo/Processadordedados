import { useState, useEffect, useRef } from "react";
// MANTENDO SEU SCHEMA: Importando apenas como TIPO
import type { UploadedFile } from "@shared/schema"; 
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileSpreadsheet, X, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Import() {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [processingLogs, setProcessingLogs] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchFiles();
    const interval = setInterval(fetchFiles, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchFiles = async () => {
    try {
      const response = await fetch('/api/files');
      if (response.ok) {
        const data = await response.json();
        setFiles(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error('Erro ao buscar arquivos:', error);
    }
  };

  const handleFileUpload = async (selectedFiles: File[]) => {
    setIsUploading(true);
    setUploadProgress(30); // Começa um pouco mais avançado
    setProcessingLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Iniciando upload de ${selectedFiles.length} arquivo(s)...`]);

    const formData = new FormData();
    selectedFiles.forEach(file => formData.append('files', file));

    try {
      const response = await fetch('/api/files/upload', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setUploadProgress(100);
        toast({
          title: "Upload concluído!",
          description: "Arquivos enviados. O servidor está processando as planilhas agora...",
        });
        setProcessingLogs(prev => [
          ...prev,
          `[${new Date().toLocaleTimeString()}] Upload finalizado → Processamento iniciado no servidor`
        ]);
        await fetchFiles();
      } else {
        const errorText = await response.text();
        throw new Error(errorText || "Erro no servidor");
      }
    } catch (error: any) {
      console.error("Erro no upload:", error);
      toast({
        variant: "destructive",
        title: "Falha no upload",
        description: error.message || "Não foi possível enviar os arquivos.",
      });
      setProcessingLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ERRO: ${error.message || 'Falha no upload'}`]);
    } finally {
      setIsUploading(false);
      setTimeout(() => setUploadProgress(0), 2000);
    }
  };

  // Funções de interface (Drag & Drop)
  const handleDrag = (e: React.DragEvent) => { 
    e.preventDefault(); 
    setDragActive(e.type === "dragenter" || e.type === "dragover"); 
  };
  const handleDrop = (e: React.DragEvent) => { 
    e.preventDefault(); 
    setDragActive(false); 
    if (e.dataTransfer.files?.length) {
      handleFileUpload(Array.from(e.dataTransfer.files));
    }
  };
  const handleFileSelect = () => fileInputRef.current?.click();
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => { 
    if (e.target.files?.length) {
      handleFileUpload(Array.from(e.target.files));
    }
  };

  const removeFile = async (id: string) => {
    try {
      await fetch(`/api/files/${id}`, { method: 'DELETE' });
      toast({ title: "Arquivo removido", description: "Registro excluído com sucesso." });
      fetchFiles();
    } catch (err) {
      toast({ variant: "destructive", title: "Erro", description: "Não foi possível remover." });
    }
  };

  const clearAllFiles = async () => {
    if (!confirm("Tem certeza? Isso vai apagar TODOS os dados do banco Neon!")) return;
    
    try {
      await fetch('/api/files', { method: 'DELETE' });
      toast({ title: "Banco limpo", description: "Todos os registros foram removidos." });
      setProcessingLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] Banco de dados limpo pelo usuário`]);
      fetchFiles();
    } catch (err) {
      toast({ variant: "destructive", title: "Erro", description: "Falha ao limpar o banco." });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed': 
        return <Badge className="bg-green-600">Completo</Badge>;
      case 'processing': 
        return <Badge className="bg-yellow-600 animate-pulse">Processando</Badge>;
      case 'failed': 
        return <Badge className="bg-red-600">Falhou</Badge>;
      default: 
        return <Badge variant="outline">Enviando</Badge>;
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto w-full h-full flex flex-col gap-6">
      <h1 className="text-3xl font-bold">DataForge Import</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
        <div className="lg:col-span-2 space-y-6">
          <input ref={fileInputRef} type="file" multiple className="hidden" onChange={handleFileInput} accept=".xlsx,.xls,.csv" />
          <Card 
            className={`border-2 border-dashed p-10 text-center cursor-pointer transition-colors ${dragActive ? "border-primary bg-primary/5" : "border-muted"}`}
            onDragOver={handleDrag} 
            onDragLeave={handleDrag} 
            onDrop={handleDrop} 
            onClick={handleFileSelect}
          >
            <Upload className="mx-auto mb-4 text-primary" size={32} />
            <h3 className="font-medium">Clique ou arraste suas planilhas</h3>
            <p className="text-xs text-muted-foreground mt-1">XLSX ou CSV até 50MB</p>
          </Card>

          <Card className="flex-1 flex flex-col min-h-0">
            <CardHeader className="flex flex-row justify-between items-center">
              <CardTitle className="text-base">Arquivos Recentes ({files.length})</CardTitle>
              {files.length > 0 && (
                <Button variant="ghost" size="sm" onClick={clearAllFiles} className="text-destructive">
                  <Trash2 size={14} className="mr-2"/> Limpar Banco
                </Button>
              )}
            </CardHeader>
            <CardContent className="p-0">
              <ScrollArea className="h-[350px] px-6">
                <AnimatePresence>
                  {files.map(file => (
                    <motion.div 
                      key={file.id} 
                      initial={{ opacity: 0 }} 
                      animate={{ opacity: 1 }} 
                      exit={{ opacity: 0 }}
                      className="flex justify-between items-center p-3 mb-2 border rounded-lg bg-card/50"
                    >
                      <div className="flex items-center gap-3">
                        <FileSpreadsheet className="text-blue-500" size={18}/>
                        <div>
                          <p className="text-sm font-medium">{file.originalName}</p>
                          <p className="text-[10px] text-muted-foreground">
                            {(file.fileSize / 1024).toFixed(0)} KB • {new Date(file.uploadedAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {getStatusBadge(file.status)}
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => removeFile(file.id)}>
                          <X size={14}/>
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
        
        <Card className="bg-zinc-950 text-zinc-300 border-zinc-800 flex flex-col h-full">
          <CardHeader className="border-b border-zinc-800">
            <CardTitle className="text-xs font-mono uppercase tracking-widest">Logs de Operação</CardTitle>
          </CardHeader>
          <CardContent className="flex-1 p-4 font-mono text-[10px]">
            <ScrollArea className="h-full">
              {processingLogs.map((log, i) => <div key={i} className="mb-1">{log}</div>)}
              {isUploading && <p className="animate-pulse text-primary">↻ Enviando e aguardando processamento...</p>}
            </ScrollArea>
          </CardContent>
          <div className="p-4 border-t border-zinc-800">
            {uploadProgress > 0 && <Progress value={uploadProgress} className="h-1 mb-2" />}
            <span className="text-[10px] text-zinc-500 uppercase">
              Status: {isUploading ? 'Ativo' : 'IDLE'}
            </span>
          </div>
        </Card>
      </div>
    </div>
  );
}
