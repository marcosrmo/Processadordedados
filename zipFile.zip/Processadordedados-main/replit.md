# DataForge - Enterprise Data Consolidation System

## Overview

DataForge is a professional-grade enterprise application for analyzing, normalizing, consolidating, and storing business data at scale. The system processes spreadsheet files (Excel and CSV), intelligently identifies and maps columns to standardized fields, and consolidates records into a unified "Golden Record" database.

Key capabilities:
- Multi-file import supporting .xlsx, .xls, and .csv formats
- Intelligent column detection using pattern matching, regex, and fuzzy matching
- Automatic field normalization for personal data, addresses, and business metrics
- Data consolidation with confidence scoring
- Export functionality for consolidated datasets

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with custom plugins for Replit integration
- **Routing**: Wouter (lightweight alternative to React Router)
- **State Management**: TanStack Query for server state, React hooks for local state
- **UI Components**: shadcn/ui built on Radix UI primitives
- **Styling**: Tailwind CSS v4 with CSS variables for theming
- **Animations**: Framer Motion for transitions

The frontend follows a page-based structure with five main views: Dashboard, Import, Analysis, Consolidation, and Export. A persistent sidebar provides navigation.

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript compiled with tsx (development) and esbuild (production)
- **API Design**: RESTful endpoints under `/api/` prefix
- **File Processing**: Multer for uploads, xlsx library for Excel parsing, papaparse for CSV
- **Build Output**: Single bundled CommonJS file for production deployment

The server handles file uploads, processes spreadsheets to extract metadata, performs intelligent column mapping, and stores results in the database.

### Data Storage
- **Database**: PostgreSQL (required via DATABASE_URL environment variable)
- **ORM**: Drizzle ORM with drizzle-zod for schema validation
- **Schema Location**: `shared/schema.ts` defines all tables
- **Migrations**: Managed via `drizzle-kit push`

Database tables:
- `uploaded_files` - Tracks imported files and processing status
- `sheet_metadata` - Stores per-sheet information (columns, rows, names)
- `column_mappings` - Records detected field mappings with confidence scores
- `consolidated_records` - The unified "Golden Record" output

### Intelligent Field Detection
The file processor (`server/fileProcessor.ts`) implements pattern-based column identification:
- Exact match against known field names (nome, cpf, telefone, etc.)
- Regex validation for structured data (CPF format, phone numbers, state codes)
- Fuzzy matching for variations and typos
- Sample value analysis for additional validation

Supported fields include: name, CPF, phone, address components (street, number, complement, neighborhood, city, state), and reference points.

## External Dependencies

### Database
- **PostgreSQL**: Required, connection via `DATABASE_URL` environment variable
- **Connection Pooling**: Configured with 10 max connections, 30s idle timeout
- **SSL**: Enabled in production mode with `rejectUnauthorized: false`

### Deployment
- Designed for Render (backend) + Supabase (PostgreSQL) deployment
- Build command: `npm run build`
- Start command: `npm run start`
- Environment variables required: `DATABASE_URL`, `NODE_ENV`

### Key NPM Packages
- `xlsx` - Excel file parsing
- `papaparse` - CSV parsing
- `drizzle-orm` / `drizzle-kit` - Database ORM and migrations
- `multer` - File upload handling
- `@tanstack/react-query` - Server state management
- `framer-motion` - UI animations